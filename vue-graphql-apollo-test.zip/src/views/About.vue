<template>
  <div class="about">
    <h1 class="page-heading">{{ $t('about.title') }}</h1>
    <p>
      Useful reading about
      <a
        href="https://www.howtographql.com/vue-apollo/0-introduction/"
        target="_blank"
      >Apollo integration</a>
    </p>

    <br />
    <br />
    <br />

    <div>
      Icons made by
      <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from
      <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a>
    </div>
  </div>
</template>
